var searchText = ["1t3", "1t4", "2t3", "2t4", "3t3", "3t4", "4t2"];

// 建立到 background 页面的连接
const port = chrome.runtime.connect();


// 监听 background 页面返回的响应消息
port.onMessage.addListener(function(response) {
  console.log('后台消息:', response);
});


window.onload = (event) => {


port.postMessage({type: 'saveData', data: {2: '321'}});
port.postMessage({type: 'readData', data: '2'});







 var h=new Date();
 var h1,m;
var millisecond = h.getTime();
 if(millisecond-localStorage.getItem("tf")>72000000){
   sessionStorage.setItem("flag", "0");
}
  localStorage.setItem("tf", millisecond);
 
 h1=h.getHours();
 m=h.getMinutes();
 if((h1==7||h1==19)&&m>=40){
  sessionStorage.setItem("flag", "0");
 }
 
if(sessionStorage.getItem("flag")=="1"){ co(); cf();

}
};

document.addEventListener('keydown', (event) => {
 console.log(event.key);
 console.log(event.keyCode);

 
if(event.keyCode==36&&event.ctrlKey){
  

if(localStorage.getItem("user")!=null){
if(sessionStorage.getItem("flag")!="1"){
 
 var ps;
 var pi; 
ps=localStorage.getItem("user");
pi=  prompt ();
 if(pi==ps){
 sessionStorage.setItem("flag", "1");
 alert ("只显示34区");
 co(); cf();
}
 
}else{ sessionStorage.setItem("flag", "0"); alert ("显示所有区");}
}else{ alert ("未设置账号");}
 }
 if(event.keyCode==35&&event.ctrlKey){
localStorage.setItem("user", prompt ());}
  
 
});

 
function co() {

 var table = document.getElementById("OnLine");
 var cells = table.getElementsByTagName("tr");

 for(var j=0;j<searchText.length;j++){
 for (var i = 1; i < cells.length; i++) {
 var Text = cells[i].getElementsByTagName("td")[0].innerText.toLowerCase(); // 将单元格文本转换为小写字母
 if (Text.indexOf(searchText[j]) != -1) {
  
  document.getElementById("OnLine").deleteRow(i);
   i--;
   
  }
 }
 }}


 var cfd=[];
var a=0,b=0,c=0;
var t=0;//找到次数
function cf() {

 var table = document.getElementById("OnLine");
 var cells = table.getElementsByTagName("tr");


 for (var i = 1; i < cells.length; i++) {
 cfd[i] = cells[i].getElementsByTagName("td")[0].innerText; 
 cff(cfd[i]);
if(c!=0){
  if(c<0.9){ 
    
 
// table.insertRow(0).innnrHTML = cells[i].innnrHTML;
  
 
 // i++;
   // table.deleteRow(i);
  
 // 
// table.insertRow(0);

// 将最后一行移到第二行
table.insertBefore(cells[i], cells[1]);
  cells[1].style.backgroundColor = "red";
    // table.deleteRow(i);
             
               
               }
  else{
       
   
      cells[i].style.backgroundColor = "#ffc107";
      
      }
}
  
 }
 }

function cff( cfff) {
 a=0;b=0;c=0;
 var table = document.getElementById("OnMachine");
 var cells = table.getElementsByTagName("tr");
var aa,bb;
 for (var i = 1; i < cells.length; i++) {
 var Text = cells[i].getElementsByTagName("td")[0].innerText; 
 if (Text.indexOf(cfff) != -1) {
   aa=parseInt(cells[i].getElementsByTagName("td")[3].innerText); 
   bb=parseInt(cells[i].getElementsByTagName("td")[4].innerText);
 
   a=aa;
   b=bb;
    console.log(a);
   console.log(b);
   c=b/a;
  console.log(c);

  //parseInt();
  }

  
 }

 
 }